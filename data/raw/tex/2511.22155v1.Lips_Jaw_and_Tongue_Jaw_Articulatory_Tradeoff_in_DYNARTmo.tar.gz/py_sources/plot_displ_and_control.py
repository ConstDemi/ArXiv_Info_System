# plot_displacement_and_control.py
import pandas as pd
import matplotlib.pyplot as plt
import os
from pathlib import Path

# === Einstellungen ===
downloads_folder = Path.home() / "Downloads"

# Neueste Dateien automatisch finden
def latest_file_with_prefix(prefix: str) -> Path:
    files = list(downloads_folder.glob(f"{prefix}_*.csv"))
    if not files:
        raise FileNotFoundError(f"Keine Datei mit Präfix '{prefix}_*.csv' im Downloads-Ordner gefunden.")
    return max(files, key=os.path.getmtime)

# Letzte displacement- und control-Dateien finden
displ_file = latest_file_with_prefix("displacement")
ctrl_file = latest_file_with_prefix("control")

print(f"Displacement-Datei: {displ_file}")
print(f"Control-Datei:      {ctrl_file}")

# CSVs laden
df_displ = pd.read_csv(displ_file)
df_ctrl = pd.read_csv(ctrl_file)

# Alle Y-Spalten in mm umrechnen (10 Pixel = 5 mm → Faktor 0.5)
for col in df_displ.columns:
   if col.startswith("y_"):
       df_displ[col] = df_displ[col] * 0.5

for col in df_ctrl.columns:
    if col != "t_msec":
       df_ctrl[col] = df_ctrl[col] * 0.001

# === Plot erstellen ===
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8), sharex=True)

# --- 1) Displacement: nur y-Spalten ---
y_cols = [col for col in df_displ.columns if col.startswith("y_")]
time_displ = df_displ["t_msec"]

for col in y_cols:
    ax1.plot(time_displ, df_displ[col], label=col)

ax1.set_ylabel("Vertical Displacement [mm]")
ax1.invert_yaxis()
ax1.set_ylim(120, 40)
ax1.legend()
ax1.legend(
    loc="center right",
    bbox_to_anchor=(0.98, 0.35)
)
ax1.grid(True)

# --- 2) Control-Parameter ---
ctrl_cols = ["vocHeight", "vocFront", "lipsClosing", "tipHeight", "dorsHeight"]
time_ctrl = df_ctrl["t_msec"]

for col in ctrl_cols:
    if col in df_ctrl.columns:
        ax2.plot(time_ctrl, df_ctrl[col], label=col)

ax2.set_ylabel("Control Parameters")
ax2.set_xlabel("Zeit (ms)")
ax2.set_ylim(-1.0, 1.2)
ax2.legend()
ax2.legend(
    loc="center right",
    bbox_to_anchor=(0.98, 0.8)
)
ax2.grid(True)

plt.tight_layout()
plt.show()